angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modal.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modal.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);

    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})
.controller('LoginCtrl', function($scope) {

})
.controller('EmailLoginCtrl', function($scope) {
  $scope.login = "true";
    $scope.signup = "false";
    $scope.showWhat = function(num) {
        if (num == "1") {
            $scope.login = "true";
            $scope.signup = "false";
        } else if (num == "2") {
            $scope.login = "false";
            $scope.signup = "true";
        }
    };

})
.controller('MyReviewsCtrl', function($scope) {
  $scope.res="true";
  $scope.food="false";
  $scope.showWhat = function (num){
    console.log(num);
    if(num == "1"){
      $scope.res="true";
      $scope.food="false";

    }
    else if(num == "2"){
      $scope.res="false";
      $scope.food="true";
    }
  }
})
.controller('MyFavCtrl', function($scope) {
  $scope.res="true";
  $scope.food="false";
  $scope.showWhat = function (num){
    if(num == "1"){
      $scope.res="true";
      $scope.food="false";

    }
    else if(num == "2"){
      $scope.res="false";
      $scope.food="true";
    }
  }
})
.controller('resListCtrl', function($scope,$ionicPopover) {
  $scope.showWhat = function (num){
    if(num == "1"){
      $scope.list="true";
      $scope.mapv="false";

    }
    else if(num == "2"){
      $scope.list="false";
      $scope.mapv="true";
      $("#map").show();
    }
  }
  var template = '<ion-popover-view><ion-header-bar> <h1 class="title">Filter</h1><button class="button button-positive button-clear">Done</button></ion-header-bar> <ion-content> <ion-checkbox ng-model="isChecked">Short by Pricing</ion-checkbox> </ion-content></ion-popover-view>';

  $scope.popover = $ionicPopover.fromTemplate(template, {
    scope: $scope
  });



  $scope.openFilter = function($event) {
    $scope.popover.show($event);
  };
  $scope.closePopover = function() {
    $scope.popover.hide();
  };
  //Cleanup the popover when we're done with it!
  $scope.$on('$destroy', function() {
    $scope.popover.remove();
  });
  // Execute action on hide popover
  $scope.$on('popover.hidden', function() {
    // Execute action
  });
  // Execute action on remove popover
  $scope.$on('popover.removed', function() {
    // Execute action
  });

})
.controller('settingsCtrl', function($scope,$ionicModal) {
  //Change Password Model
  $ionicModal.fromTemplateUrl('templates/changepassword.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(modal) {
    $scope.changepassword = modal;
  });

  $scope.openChangePasswordModel = function() {
    $scope.changepassword.show();
  };
  $scope.closeChangePasswordModal = function() {
    $scope.changepassword.hide();
  };

  // About Model
  $ionicModal.fromTemplateUrl('templates/about.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(modal) {
    $scope.about = modal;
  });
  $scope.openAboutModel = function() {
    $scope.about.show();
  };
  $scope.closeAboutModal = function() {
    $scope.about.hide();
  };

  //Terms Model
  $ionicModal.fromTemplateUrl('templates/terms.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(modal) {
    $scope.terms = modal;
  });
  $scope.openTermsModel = function() {
    $scope.terms.show();
  };
  $scope.closeTermsModal = function() {
    $scope.terms.hide();
  };

  //Privacy Model
  $ionicModal.fromTemplateUrl('templates/privacy.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(modal) {
    $scope.privacy = modal;
  });
  $scope.openPrivacyModel = function() {
    $scope.privacy.show();
  };
  $scope.closePrivacyModal = function() {
    $scope.privacy.hide();
  };
  
  //Cleanup the modal when we're done with it!
  $scope.$on('$destroy', function() {
    $scope.modal.remove();
  });
  // Execute action on hide modal
  $scope.$on('modal.hidden', function() {
    // Execute action
  });
  // Execute action on remove modal
  $scope.$on('modal.removed', function() {
    // Execute action
  });

})
.controller('ManageAddressCtrl', function($scope,$ionicModal) {
  $ionicModal.fromTemplateUrl('templates/addaddress.html', {
    scope: $scope,
    animation: 'slide-in-up'
  }).then(function(modal) {
    $scope.modal = modal;
  });
  $scope.openModal = function() {
    $scope.modal.show();
  };
  $scope.closeModal = function() {
    $scope.modal.hide();
  };
  //Cleanup the modal when we're done with it!
  $scope.$on('$destroy', function() {
    $scope.modal.remove();
  });
  // Execute action on hide modal
  $scope.$on('modal.hidden', function() {
    // Execute action
  });
  // Execute action on remove modal
  $scope.$on('modal.removed', function() {
    // Execute action
  });

})
.controller('ViewResCtrl', function($scope) {
  $scope.menu="true";
  $scope.table="false";
  $scope.offers="false";
  $scope.review="false";
  $scope.showWhat = function (num){
    if(num == "1"){
      $scope.menu="true";
      $scope.table="false";
      $scope.offers="false";
      $scope.review="false";
    }
    else if(num == "2"){
      $scope.menu="false";
      $scope.table="true";
      $scope.offers="false";
      $scope.review="false";
    }
    else if(num == "3"){
      $scope.menu="false";
      $scope.table="false";
      $scope.offers="true";
      $scope.review="false";
    }
    else if(num == "4"){
      $scope.menu="false";
      $scope.table="false";
      $scope.offers="false";
      $scope.review="true";
    }
  }
})

.controller('MapViewCtrl', function($scope, $state,$cordovaGeolocation) {
    var latLng = new google.maps.LatLng('43.07493','-89.381388'); 
    var mapOptions = {
      center: latLng,
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };
    $scope.map = new google.maps.Map(document.getElementById("map"), mapOptions);
});


